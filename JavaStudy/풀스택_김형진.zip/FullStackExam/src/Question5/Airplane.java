package Question5;

public class Airplane extends Bus{
	public void go() {
		System.out.println("비행기 타고 부산간다.");
	}
}
