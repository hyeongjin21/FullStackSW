package Question5;

public abstract class Ride {
	public void go() {
		
	}
}
