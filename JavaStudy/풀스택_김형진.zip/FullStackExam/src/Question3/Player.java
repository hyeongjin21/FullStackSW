package Question3;

public class Player {
	private String name;
	private String color;
	private boolean power;
	
	public Player(String name, String color, boolean power) {
		super();
		this.name = name;
		this.color = color;
		this.power = power;
	}
	
	public void powerOnOff(boolean onOff) {
		
	}
	
	public void play() {
		
	}
	
	public void stop() {
		
	}
	
	public int remove(int number) {
		return number;
	}
	
}
