package Question2;

public class Question2 {

	public static void main(String[] args) {
		TV myTV = new TV("LG",2034,100);
		myTV.show();
	}

}
